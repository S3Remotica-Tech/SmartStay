import React from 'react'
import Topbar from './Topbar';
import Sidebar from './Sidebar';

function RoyalGrandHostel() {
  return (
   <>
   
   <div>
<Topbar />
  </div>
   <div>
<Sidebar />
   </div>
   
   </>
  )
}

export default RoyalGrandHostel;