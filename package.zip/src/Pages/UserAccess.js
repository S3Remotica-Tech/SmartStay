import React from 'react'

function UserAccess() {
  return (
    <div>UserAccess Page</div>
  )
}

export default UserAccess