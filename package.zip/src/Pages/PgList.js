import React from 'react'

function PgList() {
  return (
    <div>PgList page</div>
  )
}

export default PgList