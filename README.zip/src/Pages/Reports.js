import React from 'react'

function Reports() {
  return (
    <div>Reports page</div>
  )
}

export default Reports