import React, { useState, useEffect } from 'react'
import Plus from '../Assets/Images/Create-button.png';
import '../Pages/Dashboard.css';
import Room from '../Assets/Images/Room.png';
import { FaAngleRight } from "react-icons/fa";
import Offcanvas from 'react-bootstrap/Offcanvas';
import { AiOutlinePlusCircle } from "react-icons/ai";
import { TiDeleteOutline } from "react-icons/ti";
import Button from 'react-bootstrap/Button';
import { useDispatch, useSelector } from 'react-redux';
import Swal from 'sweetalert2';
import { useNavigate } from 'react-router-dom';
import BedDetails from './Bed';
import { MdMeetingRoom } from "react-icons/md";

function getFloorName(floor_Id) {
    if (floor_Id === 1) {
        return 'Ground Floor';
    } else if (floor_Id === 2) {
        return '1st Floor';
    } else if (floor_Id === 3) {
        return '2nd Floor';
    } else if (floor_Id === 4) {
        return '3rd Floor';
    } else if (floor_Id >= 11 && floor_Id <= 13) {
        const id = floor_Id - 1
        console.log("id.....", id);
        return `${floor_Id}th Floor`;
    } else {
        const lastDigit = floor_Id % 10;
        let suffix = 'th';

        switch (lastDigit) {
            case 1:
                suffix = 'st';
                break;
            case 2:
                suffix = 'nd';
                break;
            case 3:
                suffix = 'rd';
                break;
        }

        return `${floor_Id - 1}${suffix} Floor`;
    }
}

function getFormattedRoomId(floor_Id, room_Id) {
    const roomIdString = String(room_Id);

    switch (floor_Id) {
        case 1:
            return `G${roomIdString.padStart(3, '0')}`;
        case 2:
            return `F${roomIdString.padStart(3, '0')}`;
        case 3:
            return `S${roomIdString.padStart(3, '0')}`;
        case 4:
            return `T${roomIdString.padStart(3, '0')}`;
        default:
            const floorAbbreviation = getFloorAbbreviation(floor_Id);
            return `${floorAbbreviation}${roomIdString.padStart(3, '0')}`;
    }
}

function getFloorAbbreviation(floor_Id) {

    switch (floor_Id) {
        case 5:
            return 'F';
        case 6:
            return 'S';
        case 8:
            return 'E';
        case 9:
            return 'N';
        case 10:
            return 'T';

        default:
            return `${floor_Id}`;
    }
}


function DashboardRoom(props) {
console.log("props",props);
    const navigate = useNavigate();
    const [roomLength,setRoomLength] = useState(0)
    const noOfFloor = Number(props.floorID) + Number(props.floorID);
    const state = useSelector(state => state)
    const dispatch = useDispatch();
    const [updateRoom, setUpdateRoom] = useState(false)
    const [shows, setShows] = useState(false);
    const handleCloses = () => {
        setRoomDetails([{ roomId: '', numberOfBeds: '' }]);
        setShows(false)
    };

    const [roomDetails, setRoomDetails] = useState([{ roomId: '', numberOfBeds: '' }
        // , { roomId: '', numberOfBeds: '' }, { roomId: '', numberOfBeds: '' }
    ]);

    const [roomCount, setRoomCount] = useState([])
   
    console.log("state.UsersList.roomFullCheck *", state);
    useEffect(() => {
        setRoomCount(state.PgList.roomCount)
    }, [state.PgList.roomCount])

    useEffect(() => {
        
        console.log("RoomCount", props.hostel_Id);
        dispatch({ type: 'ROOMCOUNT', payload: { floor_Id: props.floorID, hostel_Id: props.hostel_Id } })
        const tempArray = state.PgList.roomCount.filter((item)=>{
            console.log("item",item);
            return item[0].Floor_Id == props.floorID && item[0].id == props.hostel_Id
        })
        console.log("tempArray.",tempArray);
return ()=>{
    console.log("RoomCount unmount");
}
    }, [props.hostel_Id])

    useEffect(() => {
        if (state.PgList.createRoomMessage) {
            dispatch({ type: 'HOSTELLIST' })
            console.log("useEffect");
            dispatch({ type: 'ROOMCOUNT', payload: { floor_Id: props.floorID, hostel_Id: props.hostel_Id } })

            setTimeout(() => {
                dispatch({ type: 'UPDATE_MESSAGE_AFTER_CREATION', message: null })
            }, 100)
        }
    }, [state.PgList.createRoomMessage])

    useEffect(() => {
        dispatch({ type: 'CHECKROOM' })
    }, [])

    const handleShows = (val, index) => {
        setShows(true);
        if (val) {
            setUpdateRoom('Edit');
            setRoomDetails(prevState => {
                const updatedRooms = [...prevState];
                updatedRooms[0].roomId = val.Room_Id;
                updatedRooms[0].numberOfBeds = val.Number_Of_Beds;
                return updatedRooms;
            });
            // setR
        }
        else {
            setUpdateRoom('Add')
        }
    }
    const handleCancels = () => {
        handleCloses();
    };

    const roomDetailsFromState = state.PgList?.checkRoomList && state.PgList.checkRoomList.map(room => ({ roomId: room.RoomId, numberOfBeds: room.NumberOfBeds, hostel_Id: room.Hostel_Id, floor_Id: room.Floor_Id }));


    const handleRoomIdChange = (roomId, index) => {
        setRoomDetails(prevState => {
            const updatedRooms = [...prevState];
            updatedRooms[index].roomId = roomId;
            return updatedRooms;
        });
    };

    const handleNumberOfBedChange = (numberOfBeds, index) => {
        setRoomDetails(prevState => {
            const updatedRooms = [...prevState];
            updatedRooms[index].numberOfBeds = numberOfBeds;
            return updatedRooms;
        });
    };
    const handleAddRoom = () => {
        setRoomDetails([...roomDetails, { roomId: '', numberOfBeds: '' }]);
    };

    const handleCreateRoom = () => {
        const floorId = props.floorID.toString();
        const phoneNumber = props.phoneNumber.toString();

        const validRooms = roomDetails.filter(room => room.roomId && room.numberOfBeds);
        if (validRooms) {
            dispatch({
                type: 'CREATEROOM',
                payload: {
                    phoneNo: phoneNumber,
                    floorDetails: validRooms.map(room => ({
                        floorId: floorId,
                        roomId: room.roomId,
                        number_of_beds: room.numberOfBeds,
                    })),
                },
            });
            // dispatch({ type: 'HOSTELLIST' })
            // if (state.PgList.createRoomMessage) {
            Swal.fire({
                icon: 'success',
                title: "Room created successfully",
            }).then((result) => {
                // dispatch({ type: 'ROOMCOUNT', payload: { floor_Id: props.floorID, hostel_Id: props.hostel_Id } })                   
                if (result.isConfirmed) {
                }
            });
            setRoomDetails([{ roomId: '', numberOfBeds: '' }]);
            handleCloses();
            // }

        } else {
            Swal.fire({
                icon: 'warning',
                title: 'Please enter at least one valid room.',
            });
        }
        setRoomCount(state.PgList.roomCount)
    };
    const handleRemoveRoomDetails = (indexToRemove) => {
        setRoomDetails((prevDetails) => prevDetails.filter((_, index) => index !== indexToRemove));
    };
    const arr = [];
    console.log("state", state);
    // const handleRoomDetails = (val) => {

    //     navigate('/Bed', { state: { val: val } });
    // }
   const handleRoomDetails = (val) => {
        props.onRowVisibilityChange(false);
        props.onRowBedVisibilityChange(true,val)
    }

    return (
        <>
            <div className="col-lg-2 col-md-4  col-sm-12 col-xs-12 col-12">

                <div className="card h-100" style={{ boxShadow: "0 4px 8px rgba(0, 0, 0,0.3)", width: "auto", maxWidth: 400 }}>

                    <div className="card-header d-flex justify-content-between p-2" style={{ backgroundColor: "#f6f7fb" }}><strong style={{ fontSize: "13px" }}>{getFloorName(props.floorID)}</strong><FaAngleRight className="" style={{ height: "15px", width: "15px", color: "grey" }} /></div>

                    <div className="card-body">
                        <p className="card-title text-center" style={{ fontWeight: 600 }}>({arr}) Rooms</p>
                        {/* <p className="card-title text-center" style={{ fontWeight: 600 }}>({state.PgList.roomCount[props.floorID - 1] && state.PgList.roomCount[props.floorID - 1].length > 0 ? state.PgList.roomCount[props.floorID - 1].length : 0}) Rooms</p> */}
                        {/* <p className="card-title text-center" style={{ fontWeight: 600 }}>({state.PgList.roomCount[props.floorID - 1].length >0 ? state.PgList.roomCount[props.floorID - 1].length : 0}) Rooms</p> */}

                        <div className="row  row-gap-3  pe-3">
                            {

                                roomCount.length > 0 && roomCount.map((room) => {

                                    return (
                                        <>
                                            {room.length > 0 &&
                                                room.map((val, index) => {
                                                    if (val.Floor_Id == props.floorID) {
                                                        arr.length == 0 && arr.push(room.length)
                                                        // setRoomLength(room.length)
                                                        const formattedRoomId = getFormattedRoomId(val.Floor_Id, val.Room_Id);
                                                        // const isFiltered = RoomFull.some(item =>
                                                        //     item.length > 0 &&
                                                        //     item.some(room =>
                                                        //         room.Room_Id === val.Room_Id &&
                                                        //         room.Floor_Id === val.Floor_Id &&
                                                        //         room.Hostel_Id === val.Hostel_Id
                                                        //     )
                                                        // )
                                                        // console.log("isFiltered",isFiltered);
                                                        return (
                                                            <>

                                                                <div className="col-4" key={index} >
                                                                    <div className="card  text-center align-items-center" style={{ height: "60px", width: 35, borderRadius: "5px", backgroundColor: val.Number_Of_Beds - val.bookedBedCount == 0 ? "#25D366" : "#e3e4e8" }} onClick={() => { handleRoomDetails(val) }}>
                                                                        <img src={Room} style={{ height: "100px", width: "35px", paddingTop: "1px", filter: val.Number_Of_Beds - val.bookedBedCount == 0 ? "brightness(0) invert(1)" : "none" }} alt='Room' />
                                                                        <p style={{ marginTop: "2px", fontSize: "10px", fontWeight: 600, color: val.Number_Of_Beds - val.bookedBedCount == 0 ? "white" : "gray" }}>
                                                                            {formattedRoomId}
                                                                        </p>
                                                                    </div>
                                                                </div>
                                                                {/* <p className="card-title text-center" style={{ fontWeight: 600 }}>({arr}) Rooms</p> */}
                                                                {/* <p className="card-title text-center" style={{ fontWeight: 600 }}>({room.length}) Rooms</p> */}
                                                                {/* <div className="col-4">
                                                                    <div className="card d-flex text-center align-items-center justify-content-center" style={{ height: "60px", width: 35, borderRadius: "5px", 
                                                                     backgroundColor: filteredBackgroundColor
                                                                    }} onClick={() => { handleRoomDetails(val)}}> */}
                                                                {/* <img src={Room} style={{ height: "100px", width: "35px", paddingTop: "1px", 
                                                                         color: filteredColor
                                                                        }} alt='Room' /> */}
                                                                {/* <div><MdMeetingRoom  style={{color:filteredColor,fontSize: 40,paddingTop:5}}/>
                                                                        <p style={{ marginTop: "2px", fontSize: "10px", fontWeight: 600 ,marginBottom:0,
                                                                         color:filteredColor
                                                                        }}>
                                                                            {formattedRoomId}
                                                                        </p></div>
                                                                    </div>
                                                                </div> */}
                                                                {/* <div className="col-4"
                                                                    key={val.id}>
                                                                    <div className="card  text-center align-items-center" style={{ height: "60px", width: 35, borderRadius: "5px", backgroundColor: "#f6f7fb" }} onClick={() => { handleRoomDetails()}}>
                                                                        <img src={Room} style={{ height: "100px", width: "35px", paddingTop: "1px", color: "gray" }} alt='Room' />
                                                                        <p style={{ marginTop: "2px", fontSize: "10px", fontWeight: 600 }}>
                                                                            {formattedRoomId}
                                                                        </p>
                                                                    </div>
                                                                </div> */}
                                                            </>
                                                        )
                                                    }
                                                })
                                            }
                                        </>
                                    )
                                })

                            }

                            <div className="col-4">
                                <div className="card  text-center align-items-center" style={{ height: "60px", width: "35px", borderRadius: "5px", border: "1px solid #2E75EA", backgroundColor: "#cccccc11" }} onClick={() => { handleShows() }}>
                                    <img src={Plus} className="pt-2 mb-0" height="25" width="15" alt='Room' />
                                    <p style={{ color: "#1F75FE", paddingTop: "2px", fontSize: "10px", fontWeight: 600 }} className="mb-0" >Create Room</p>
                                </div>
                            </div>
                        </div >
                    </div>
                </div>
            </div>
            <Offcanvas show={shows} onHide={handleCloses} placement="end" style={{ width: "70vh" }}>
                <Offcanvas.Title style={{ backgroundColor: "#0D6EFD", width: "100%", color: "white", fontSize: "15px", height: "30px", fontWeight: "700" }} className="ps-3">Create PG</Offcanvas.Title>
                <Offcanvas.Body>
                    <h4 style={{ fontSize: 14, fontWeight: 600 }}>Create Room</h4>
                    <p className="text-justify" style={{ fontSize: "11px" }}>Generate revenue from your audience by promoting SmartStay hotels and homes.Be a part of SmartStay Circle, and invite-only,global community of social media influencers and affiliate networks.</p>


                    <div className="row column-gap-3 g-3 d-flex align-items-center ">
                        {roomDetails.map((room, index) => (
                            <>
                                {
                                    updateRoom === 'Add' &&
                                    roomDetailsFromState && roomDetailsFromState.some(existingRoom => existingRoom.hostel_Id === props.hostel_Id && existingRoom.floor_Id === props.floorID && String(existingRoom.roomId) === String(room.roomId)) && (
                                        <div className="p-2" style={{ borderRadius: 2, color: 'white', backgroundColor: "#f71b2e", fontSize: '13px' }}>
                                            RoomId <strong>{room.roomId}</strong> is already exists &
                                            available beds are <strong style={{ color: "white" }}>{roomDetailsFromState.find(existingRoom => existingRoom.hostel_Id === props.hostel_Id && existingRoom.floor_Id === props.floorID && String(existingRoom.roomId) === String(room.roomId))?.numberOfBeds}</strong>
                                        </div>
                                    )
                                }
                                {
                                    updateRoom === 'Edit' ?
                                        <>
                                            <div key={index} className="col-lg-6 col-md-12 col-xs-12 col-sm-12 col-12 mb-4" style={{ backgroundColor: "#F6F7FB", height: "60px", borderRadius: "5px" }}>
                                                <div className="form-group mb-4 p-2 d-flex flex-column">
                                                    <label htmlFor={`roomNumber${index}`} className="form-label mb-1" style={{ fontSize: "11px" }}><b>Room Number : </b></label>
                                                    <label htmlFor={`roomNumber${index}`} className="form-label mb-1" style={{ fontSize: "11px" }}>{room.roomId}</label>
                                                </div>
                                            </div>
                                        </>
                                        :
                                        <>
                                            <div key={index} className="col-lg-6 col-md-12 col-xs-12 col-sm-12 col-12 mb-4" style={{ backgroundColor: "#F6F7FB", height: "60px", borderRadius: "5px" }}>
                                                <div className="form-group mb-4 ps-1">
                                                    <label htmlFor={`roomNumber${index}`} className="form-label mb-1" style={{ fontSize: "11px" }}>Room Number</label>
                                                    <input
                                                        type="text"
                                                        value={room.roomId}
                                                        onChange={(e) => handleRoomIdChange(e.target.value, index)}
                                                        className="form-control custom-border-bottom p-0"
                                                        id={`roomNumber${index}`}
                                                        placeholder="Enter here"
                                                        style={{ boxShadow: "none", fontSize: "11px", backgroundColor: "#F6F7FB", fontWeight: 700, borderTop: "none", borderLeft: "none", borderRadius: 0, borderRight: "none", borderBottom: "1px solid lightgray" }}
                                                    />
                                                </div>
                                            </div>
                                        </>
                                }



                                <div key={`beds${index}`} className="col-lg-4 col-md-12 col-xs-12 col-sm-12 col-12 mb-4" style={{ backgroundColor: "#F6F7FB", height: "60px", borderRadius: "5px" }}>
                                    <div className="form-group mb-4 ps-1">
                                        <label htmlFor={`bedsNumber${index}`} className="form-label mb-1" style={{ fontSize: "11px" }}>Number of Beds</label>
                                        <div className="d-flex">
                                            <input
                                                type="text"
                                                value={room.numberOfBeds}
                                                onChange={(e) => handleNumberOfBedChange(e.target.value, index)}
                                                className="form-control custom-border-bottom p-0"
                                                id={`bedsNumber${index}`}
                                                placeholder="Enter here"
                                                style={{ boxShadow: "none", fontSize: "11px", backgroundColor: "#F6F7FB", fontWeight: 700, borderTop: "none", borderLeft: "none", borderRadius: 0, borderRight: "none", borderBottom: "1px solid lightgray" }}
                                            />
                                        </div>
                                    </div>
                                </div>

                                {index > 0 &&
                                    <div className="col-lg-1">
                                        <TiDeleteOutline style={{ fontSize: 18, color: "red", cursor: "pointer" }} onClick={() => handleRemoveRoomDetails(index)} />
                                    </div>
                                }

                            </>
                        ))}
                    </div>
                    <div onClick={handleAddRoom}>
                        <AiOutlinePlusCircle style={{ height: "30px" }} /> <label style={{ color: "gray", fontSize: "14px" }}>Add Room</label>
                    </div>
                    <hr style={{ marginTop: "100px" }} />

                    <div className="d-flex justify-content-end" style={{ marginTop: "15px" }} >
                        <Button variant="outline-secondary" className='ms-2 me-2' size="sm" style={{ width: "90px", borderRadius: 200 }} onClick={handleCancels}>
                            Cancel
                        </Button>
                        <Button variant="outline-primary" className='ms-2 me-2' size="sm" style={{ borderRadius: 200, width: "80px" }} onClick={handleCreateRoom}>
                            {updateRoom == 'Add' ? "Save" : "Update"}
                        </Button>
                    </div>
                </Offcanvas.Body>
            </Offcanvas>


        </>)
}

export default React.memo(DashboardRoom) ;